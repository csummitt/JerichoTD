This game is a loosely futuristic alteration of the Biblical Battle of Jericho. Found in Joshua 6:1-27.
			In this game you will play as a colony of Jericho that was settled on an inhabital planet by some early pioneers from earth. Unpon settling the pioneers learned quickly that the 
			in habitants of the planet were anything but peaceful. Working fast they came up with a solution to produce an energy resonating shielding that would stop organic materail from passing through. This shield 
			since constructed in haste has a tendency to overheat if the event horizon is struck continuously. Once the shield over heats the alien lifeforms then have free access to attack the colony with ease. You job
			as city defender to construct an array of turrets consisting of different payloads to hold of the enemies and to keep them from over-heating the sheild.
			
			The goal in this game is to survive as long as possible, added by abilities and tower enhancedments aquired by gaining levels from experience which is awarded after
			each play through
			
			source code can be found at https://github.com/csummitt/JerichoTD.git
			Phonegap build can be found at https://build.phonegap.com/apps/1112991